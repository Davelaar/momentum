Deze map bevat samples voor analyse van schema's en I/O:
- var/universe.json            : universe schema & inhoud
- var/positions.json           : posities (sample)
- var/open_orders_state.json   : open orders (sample)
- var/own_trades_state.json    : trades (sample)
- var/ws_payloads.json         : laatst gebouwde order-payloads (dry-run)
- var/*_hb.txt                 : heartbeats (indien aanwezig)
- var/funnel/**                : funnel resultaten (indien aanwezig)
- *.tail.log                   : beperkte log-staart (max 300 regels)
